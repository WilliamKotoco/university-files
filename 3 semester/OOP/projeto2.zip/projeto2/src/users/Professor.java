package src.users;
import src.Itens.Item;
import src.Enums.Departamentos;
import src.Enums.Titulacao;

import java.util.ArrayList;

/**
 * Classe professor, sendo uma especifidade do usuário.
 */
public class Professor extends Usuario{
    private Departamentos dpto;
    private Titulacao titulacao;

    public Professor(String nome, long matricula, Departamentos dpto, Titulacao titulacao) {
        super(nome, matricula );
        this.dpto = dpto;
        this.titulacao = titulacao;
    }

    public Departamentos getDpto() {
        return dpto;
    }

    public void setDpto(Departamentos dpto) {
        this.dpto = dpto;
    }

    public Titulacao getTitulacao() {
        return titulacao;
    }

    public void setTitulacao(Titulacao titulacao) {
        this.titulacao = titulacao;
    }

    /**
     * Maneira especpifica de calcular a multa do professor
     * sendo 25% a mais da multa do aluno.
     * @param diasAtraso
     * @return multa
     */
    @Override
    public double calcularMulta(int diasAtraso) {
        double multaAluno = 5 * diasAtraso;
        return multaAluno + 0.25 * multaAluno;
    }

    /**
     * Imprime informação do professor
     * @return
     */
    public String toString()
    {
        return "Nome: " + titulacao.getTitle() +" "+ getNome() + "\nMatrícula: " + getMatricula() +
                 "\nDepartamento: " + dpto.getTitle();
    }
}
