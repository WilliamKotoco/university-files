package src.users;
import src.Enums.Cursos;
import src.Itens.Item;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Classe aluno, que é um usúario mais específico.
 */
public class Aluno extends Usuario implements Serializable {
    private Cursos curso;
    private int periodo;

    public Aluno(String nome, long matricula, Cursos curso, int periodo) {
        super(nome, matricula);
        this.curso = curso;
        this.periodo = periodo;
    }

    /**
     * Maneira específica para o aluno de se calcular a multa, sendo 5 * os dias de atraso.
     * @param diasAtraso
     * @return preço da multa
     */
    @Override
    public double calcularMulta(int diasAtraso)
    {
        return 5*diasAtraso;
    }

    public Cursos getCurso() {
        return curso;
    }

    public void setCurso(Cursos curso) {
        this.curso = curso;
    }

    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }

    /**
     * Imprime informação do aluno.
     * @return
     */
    public String toString()
    {
        return "Nome: " + getNome() + "\nMatrícula: " + getMatricula() +
                "\nCurso: " + curso.getTitulo() + "\nPeriodo: " + periodo;

    }



}
