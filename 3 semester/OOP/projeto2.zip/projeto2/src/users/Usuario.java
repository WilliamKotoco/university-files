package src.users;
import src.Itens.Item;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe abstrata usuário, que serve de base para a criação das suas subclasses.
 * Implemente métodos e atributos comuns para todos os usuários do sistema.
 *
 */
public abstract class Usuario implements Serializable {

    private String nome;
    private long matricula;
    private ArrayList<Item> itens = new ArrayList<>();
    /*
    Livro, revista, cd são todos itens, então posso usar uma lista só.
     */

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getMatricula() {
        return matricula;
    }

    public void setMatricula(Long matricula) {
        this.matricula = matricula;
    }

    public ArrayList<Item> getItens() {
        return itens;
    }

    public void setItens(ArrayList<Item> itens) {
        this.itens = itens;
    }

    public void addIndividualItem(Item item) {this.itens.add(item);}


    public Usuario(String nome, long matricula) {
        this.nome = nome;
        this.matricula = matricula;
    }



    /**
     * O cálculo da multa será diferente de acordo com cada subclasse.
     * @return o preço da multa
     */
    public abstract double calcularMulta(int diasAtraso);

    /**
     * Método static para buscar um usuário passando somente o nome e a lista de
     * usuários. Retorna nulo se não encontrar usuário
     * @param user
     * @param nome
     * @return objeto Usuario ou nulo
     */
    public static Usuario userBusca(ArrayList<Usuario> user, String nome)
    {
        for (Usuario usuario : user) {
            if (usuario.getNome().equalsIgnoreCase((nome)))
                return usuario;
        }
        return null;
    }

    /**
     * Lista todos os itens adquiridos por um usuário
     * @param users lista de usuários
     */
    public static void listaUsuario(ArrayList<Usuario> users)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite a mátricula para busca");
        Usuario usuario = null;
        long matricula = input.nextLong();
        for (Usuario user : users) {
            if(user.getMatricula() == matricula)
            {
                usuario = user;
            }
            
        }
        if (usuario == null)
        {
            System.out.println("Usuário não encontrado");
            return;
        }
        for (Item iten : usuario.getItens()) {
            System.out.println(iten.getTitulo());
            System.out.println();
        }
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    



    
}
