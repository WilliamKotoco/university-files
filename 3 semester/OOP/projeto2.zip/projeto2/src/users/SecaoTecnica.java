package src.users;

import src.Enums.Secao;
import src.Itens.Item;

import java.util.ArrayList;

/**
 * Classe SecaoTecnica, sendo uma especifidade do usuário.
 */
public class SecaoTecnica extends Usuario{
private Secao secao;

    public SecaoTecnica(String nome, long matricula, Secao secao) {
        super(nome, matricula);
        this.secao = secao;
    }

    /**
     * Maneira específica da Seção Técnica de calcular multa, sedo 15 % a mais da multa do aluno
     * @param diasAtraso
     * @return multa
     */
    @Override
    public double calcularMulta(int diasAtraso) {
        double multaAluno = 5 * diasAtraso;
        return multaAluno + 0.15 * multaAluno;
    }

    /**
     * Imprime as informações da seção técnica.
     * @return
     */
    public String toString()
    {
        return "Nome: "+ getNome() + "\nMatrícula: " + getMatricula() +
                "\nSeção: " + secao.getTitle();
    }

}
