package src.Exceptions;

/**
 * Exceção para caso o usuário procure por um empréstimo que não existe.
 */
public class NonExistentLoan extends Exception {
    public NonExistentLoan(String message) {
        System.out.println(message);;
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
