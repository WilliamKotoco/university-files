package src.Exceptions;

/**
 * Exceção caso o usuário tente cadastrar um empréstimo de um item indisponível.
 */
public class UnavaliableItemException extends  Exception{
    public UnavaliableItemException(String message) {
        super(message);
    }
}
