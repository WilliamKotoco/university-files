package src.system;

import src.Enums.Cursos;
import src.Enums.Departamentos;
import src.Enums.Secao;
import src.Enums.Titulacao;
import src.Exceptions.UnavaliableItemException;
import src.Itens.CD;
import src.Itens.Item;
import src.Itens.Livro;
import src.Itens.Revista;
import src.users.*;
import src.util.LeitorArquivos;
import src.util.SalvarArquivo;

import java.io.*;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe principal do sistema, é responsável por cadastrar e guardar os dados, tais quais
 * itens, empréstimos e usuários.
 */
public class Biblioteca  implements Serializable {
    private static ArrayList<Item> itens = new ArrayList<>();
    private static ArrayList<Usuario> users = new ArrayList<>();
    private static ArrayList<Emprestimo> emprestimos = new ArrayList<>();
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Lê os dados e guarda-os para não precisar consultar o disco toda hora.
        setItens(LeitorArquivos.readItensFile());
        setUsers(LeitorArquivos.readUsersFile());;
        setEmprestimos(LeitorArquivos.lerEmprestimos());

        // informações básicas do sistema
        System.out.println("Número de usuários: " + users.size());
        System.out.println("Número de empréstimos: " + emprestimos.size());
        System.out.println(users.get(0));

        int res = 0;
        do{
            System.out.println("Digite [1] para cadastrar empréstimo");
            System.out.println("Digite [2] para cadastrar usuário");
            System.out.println("Digite [3] para cadastrar item");
            System.out.println("Digite [4] para verificar itens de um usuário");
            System.out.println("Digite [5] para cadastrar uma devolução");
            System.out.println("Digite [6] para sair");
            res = input.nextInt();
            input.nextLine();
            switch (res) {
                case 1 -> cadastrarEmprestimo();
                case 2 -> cadastrarUser();
                case 3 -> cadastrarItem();
                case 4 -> Usuario.listaUsuario(users);
                case 5 -> emprestimos.remove(Emprestimo.cadastrarDevolucao(emprestimos, users));
            }

        }while (res != 6);

        // salva os usuários novamente, pois podem haver mudanças posteriores que não
        // são salvadas diretamente na operação.
        SalvarArquivo.salvarUsuario(users);

    }

    public static ArrayList<Usuario> getUsers() {
        return users;
    }

    public static void setUsers(ArrayList<Usuario> users) {
        Biblioteca.users = users;
    }


    public static ArrayList<Item> getItens() {
        return itens;
    }

    public static ArrayList<Emprestimo> getEmprestimos() {
        return emprestimos;
    }

    public static void setEmprestimos(ArrayList<Emprestimo> emprestimos) {
        Biblioteca.emprestimos = emprestimos;
    }

    public static void setItens(ArrayList<Item> itens) {
        Biblioteca.itens = itens;
    }

    /**
     * Cadastra um usuário recebendo seus campos do console, e chama a classe SalvarArquivo para salvar em um arquivo
     * serializável.
     */
    public static void  cadastrarUser()  {
        int i;
        String nome;
        long matricula;
        Scanner input = new Scanner(System.in);
        Scanner input2 = new Scanner(System.in);
        System.out.println("Digite a letra para o tipo de usuário");
        System.out.println("[1] para aluno \n [2] para professor \n [3] para Seção Técnica");
        int op = input.nextInt();
        System.out.println("Digite a matrícula: ");
        matricula = input.nextLong();
        System.out.println("Digite o nome: ");
        nome = input2.nextLine();
        Usuario user;
        if (op == 1)
        {
           user = createAluno(nome, matricula);
           Aluno aluno = (Aluno) user;
           users.add(aluno);

        }
        else if (op == 2)
        {
        user = createProfessor(nome, matricula);
        Professor prof = (Professor)  user;
        users.add(prof);
;
        }
        else
        {
            user = createSecao(nome, matricula);
            SecaoTecnica sec = (SecaoTecnica) user;
            users.add(sec);


        }
        SalvarArquivo.salvarUsuario(users);


    }

    /**
     * Um complemento à classe de cadastrar usuário, completando o cadastro apenas
     * para um aluno.
     * @param nome
     * @param matricula
     * @return objeto Aluno com os dados cadastrados.
     */
    public static Aluno createAluno(String nome, long matricula)
    {
        Scanner input = new Scanner(System.in);
        Cursos curso = null;
        System.out.println("Digite o número do curso");
       for (Cursos cursoIter : Cursos.values())
       {
           System.out.println(cursoIter.getId() + " " + cursoIter.getTitulo());
       }
       int op = input.nextInt();
        switch (op) {
            case 1 -> curso = Cursos.CIENCIA_COMPUTACAO;
            case 2 -> curso = Cursos.FISICA;
            case 3 -> curso = Cursos.MATEMATICA;
            case 4 -> curso = Cursos.PEDAGOGIA;
            case 5 -> curso = Cursos.TRADUCAO;
            case 6 -> curso = Cursos.LETRAS;
            case 7 -> curso = Cursos.QUIMICA;
            case 8 -> curso = Cursos.ENGENHARIA_ALIMENTOS;
            default -> System.out.println("Opção inválida.");
        }
        System.out.println("Digite o período: ");
        int per = input.nextInt();

        return new Aluno(nome, matricula, curso, per);


    }

    /**
     * Um complemento à classe de cadastrar usuário, completando o cadastro apenas
     *  para um Professor.
     * @param nome
     * @param matricula
     * @return objeto Professor com os dados prontos
     */
    public static Professor createProfessor(String nome, long matricula)
    {
        Scanner input = new Scanner(System.in);
        Departamentos dpto = null;
        System.out.println("Digite o departamento: ");
        for (Departamentos dptoIter : Departamentos.values())
        {
            System.out.println(dptoIter.getId() + " - " + dptoIter.getTitle());
        }
        int op = input.nextInt();
        switch (op) {
            case 1 -> dpto = Departamentos.DCCE;
            case 2 -> dpto = Departamentos.DMAT;
            case 3 -> dpto = Departamentos.DCB;
            case 4 -> dpto = Departamentos.DE;
            case 5 -> dpto = Departamentos.DETA;
            case 6 -> dpto = Departamentos.DELL;
            case 7 -> dpto = Departamentos.DF;
            case 8 -> dpto = Departamentos.DLM;
            case 9 -> dpto = Departamentos.DQCA;
            default -> System.out.println("Opção inválida.");
        }
        System.out.println("Digite o título: ");
        Titulacao title = null;
        for (Titulacao titulacaoIter : Titulacao.values())
        {
            System.out.println(titulacaoIter.getId() + " - "  +titulacaoIter.getTitle() );
        }
        op = input.nextInt();
        switch (op) {
            case 1 -> title = Titulacao.MESTRADO;
            case 2 -> title = Titulacao.DOUTORADO;
            case 3 -> title = Titulacao.POS_DOUTORADO;
            default -> System.out.println("Opção inválida.");
        }
            return new Professor(nome, matricula, dpto, title);


    }

    /**
     * Complemento à classe cadastrar usuário, completamndo um cadastro apenas para a
     * seção técnica.
     * @param nome
     * @param matricula
     * @return um objeto SecaoTecnica com os dados prontos
     */
    public static SecaoTecnica createSecao(String nome, long matricula)
    {
        Scanner input = new Scanner(System.in);
        Secao sec = null;
        for (Secao sec_iter : Secao.values())
        {
            System.out.println(sec_iter.getId() + " - " + sec_iter.getTitle());
        }
        int op = input.nextInt();
        switch (op) {
            case 1 -> sec = Secao.ACADEMICA;
            case 2 -> sec = Secao.POS_GRADUACAO;
            case 3 -> sec = Secao.GRADUACAO;
            case 4 -> sec = Secao.ADMINISTRATIVA;
            case 5 -> sec = Secao.SAUDE;
            default -> System.out.println("Opção inválida.");
        }
        return new SecaoTecnica(nome, matricula, sec);

    }

    /**
     * Recebe do teclado o nome de um item e o nome de um usuário. Realiza a busca
     * dos tais e, caso encontre-os, cadastra um empréstimo com a data de devolução para
     * 7 dias. Imprime o resumo do empréstimo e salva nos arquivos.
     */
    public static void cadastrarEmprestimo() {
        Scanner input = new Scanner(System.in);
        // por algum motivo não da para ler duas strings no mesmo input sem bugar
        Scanner input2 = new Scanner(System.in);
        int tmp, tmp2;
        Item item = new Item() {
        };
        boolean sucess = false;
        String name;
        while(!sucess) {
            System.out.println("Digite o nome do item: ");
            name = input.nextLine();
            try {
                item = Item.searchForItem(itens, name);
            } catch (UnavaliableItemException e) {
                System.out.println(e.getMessage());
            }
            if (item != null)
            {
                System.out.println(item);
                System.out.println("Digite 1 para confirmar");
                tmp = input.nextInt();
                if (tmp == 1)
                {
                    Usuario user;

                    System.out.println("Digite o nome do usuário: ");
                    name = input.next();
                    user = Usuario.userBusca(users, name);
                    if(user != null)
                    {
                        System.out.println(user);
                        System.out.println("Digite 1 para confirmar");
                        tmp2 = input.nextInt();
                        if(tmp2 == 1)
                        {
                            // chamar classe emprstimo para imprimir o emprstimo e fazer o resto
                            Emprestimo emprestimo = new Emprestimo(LocalDate.now().plusDays(7), null, item, user);
                            emprestimos.add(emprestimo);
                            user.addIndividualItem(emprestimo.getItem());
                            SalvarArquivo.salvarEmprestimo(emprestimos);
                            System.out.println(emprestimo.toString());
                            try {
                                Thread.sleep(5000);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }

                    }
                    else
                    {
                        System.out.println(("Usuário não encontrado"));
                       continue;
                    }

                }

                sucess = true;

            }
        }

    }

    /**
     * Cadastra um item, dando append no arquivo.
     */
    public static void cadastrarItem()
    {
        Scanner input = new Scanner(System.in);
        Scanner input2 = new Scanner(System.in);

        String titulo, autor, tipostr, linha;
        int ano, qtdDisponivel, tipo ;
        Item item;
        System.out.println("[1] para livro \n [2] para revista \n [3] para CD");
        tipo = input.nextInt();
        System.out.println("Digite o título: ");
        titulo = input2.nextLine();
        System.out.println("Digite o autor: ");
        autor = input2.nextLine();
        System.out.println("Digite o ano");
        ano = input.nextInt();


        System.out.println("Digite a quantidade disponível: ");
        qtdDisponivel = input.nextInt();
        if (tipo == 1) {
            String editora, ISBN;
            System.out.println("Digite a editora: ");
            editora = input.next();
            System.out.println("Digite o ISBN");
            ISBN = input.next();
            item = (Livro) new Livro(titulo.concat("."), autor, ano, qtdDisponivel, 0 ,editora, ISBN);
            tipostr = "Livro";
             linha = tipostr + "#" + titulo + "#" + autor + "#" + ano + "#" + qtdDisponivel + "#" + 0 + "#" + editora + "#" + ISBN;


        }
        else if (tipo == 2)
        {
            String volume;
            int number;
            System.out.println("Digite o volume: ");
            volume = input.next();
            System.out.println("Digite o número");
            number = input.nextInt();
            item = (Revista) new Revista(titulo.concat(".") ,autor, ano, qtdDisponivel, 0 ,volume, number);
            tipostr = "Revista";
             linha = tipostr + "#" + titulo + "#" + autor + "#" + ano + "#" + qtdDisponivel + "#" + 0 + "#" + volume + "#" + number;

        }
        else
        {
            String volume, gravadora;
            System.out.println("Digite o volume: ");
            volume = input.next();
            System.out.println("Digite o número: ");
            gravadora = input.next();
            item = (CD) new CD(titulo.concat("."), autor, ano ,qtdDisponivel, 0, volume,gravadora);
            tipostr = "CD";
             linha = tipostr + "#" + titulo + "#" + autor + "#" + ano + "#" + qtdDisponivel + "#" + 0 + "#" + volume + "#" + gravadora;

        }
        itens.add(item);
        SalvarArquivo.salvarItemIndividual(linha);
    }

}
