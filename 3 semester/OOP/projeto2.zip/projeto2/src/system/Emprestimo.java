package src.system;

import src.Exceptions.NonExistentLoan;
import src.Itens.Item;
import src.users.Usuario;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe empréstimo
 */
public class Emprestimo implements Serializable {

   private LocalDate dataDevolucao;
    private LocalDate dataDevolvido;
    private Item item;
    private Usuario user;

    /**
     * Cadastra a devolução de um item, retornando se há multa ou não sobre ele
     * @param emprestimos
     * @return o emprestimo que foi devolvido
     */
    public static Emprestimo cadastrarDevolucao(ArrayList<Emprestimo> emprestimos, ArrayList<Usuario> users)
    {
        Scanner input = new Scanner(System.in);
        Emprestimo emprestimo = null;
        System.out.println("Digite a mátricula do usúario e, separando com uma barra," +
                "o nome do item." +
                "\n Exemplo: 234/Livro nome");
        String linha = input.nextLine();
        String[] campos = linha.split("/");
        long matricula = Long.parseLong(campos[0]);
        try {
            emprestimo =  procuraEmprestimo(matricula, campos[1].concat("."), emprestimos);
        } catch (NonExistentLoan e) {
            System.out.println(e);
            return null;
        }
        System.out.println("Digite a data de devolução no formato mes e dia" +
                ", separado por espaços" +
                "\n exemplo: 10 29 (29 de outubro) ");
        LocalDate devolvido = LocalDate.of(LocalDate.now().getYear(), input.nextInt(), input.nextInt());
        long dias_apos = Math.abs(ChronoUnit.DAYS.between(emprestimo.getDataDevolucao(), devolvido));

        if (dias_apos > 7)
            System.out.println("MULTA DE "  + emprestimo.user.calcularMulta((int) (dias_apos - 7)));
         emprestimo.user.getItens().remove(emprestimo.item);
            System.out.println("Item devolvido com sucesso.");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return emprestimo;

    }

    /**
     * Procura um empréstimo, passando a matrícula do usuário e o item que foi emprestado
     * @param matricula
     * @param item
     * @param emprestimos
     * @return o empréstimo em si
     * @throws NonExistentLoan
     */
    public static Emprestimo procuraEmprestimo(long matricula, String item, ArrayList<Emprestimo> emprestimos) throws NonExistentLoan {
        for (Emprestimo emprestimo : emprestimos) {
            if ((emprestimo.getItem().getTitulo().equalsIgnoreCase(item)
                    || emprestimo.getItem().getTitulo().contains(item.subSequence(0, 10))
            && emprestimo.getUser().getMatricula() == matricula))
                return emprestimo;
            
        }
        throw  new NonExistentLoan("Esse item não foi emprestado para esse usuário");
    }

    public Emprestimo(LocalDate dataDevolucao, LocalDate dataDevolvido, Item item, Usuario user) {
        this.dataDevolucao = dataDevolucao;
        this.dataDevolvido = dataDevolvido;
        this.item = item;
        this.user = user;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public LocalDate getDataDevolvido() {
        return dataDevolvido;
    }

    public void setDataDevolvido(LocalDate dataDevolvido) {
        this.dataDevolvido = dataDevolvido;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Usuario getUser() {
        return user;
    }

    public void setUser(Usuario user) {
        this.user = user;
    }

    /**
     * Imprime informações do usúario
     * @return
     */
    public String toString()
    {
      return "Item " + item.getTitulo().replace(".", "") + " entregue à  " + user.getNome() + "\n deverá ser devolvido em: " + dataDevolucao.toString();
    }


}
