package src.Itens;

/**
 * classe CD, que é uma especifidade de item
 */
public class CD extends  Item{
    String volume;
    String gravadora;

    public CD(String titulo, String autor, int ano, int quantidadeDisponivel, int quantidadeEmprestada, String volume, String gravadora) {
        super(titulo, autor, ano, quantidadeDisponivel, quantidadeEmprestada);
        this.volume = volume;
        this.gravadora = gravadora;
    }

    /**
     * Imprime informações do CD
     * @return
     */
    @Override
    public String toString()
    {
        return "Título: " + getTitulo() + "\nAutor " + getAutor() + "\nGravadora:  " + gravadora
                + "\nVol: " +  volume +  "\nAno " + getAno();
    }
}
