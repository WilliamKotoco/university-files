package src.Itens;

/**
 * Classe específica de item.
 */
public class Revista extends Item {
    String volume;
    int numero;

    public Revista(String titulo, String autor, int ano, int quantidadeDisponivel, int quantidadeEmprestada, String volume, int numero) {
        super(titulo, autor, ano, quantidadeDisponivel, quantidadeEmprestada);
        this.volume = volume;
        this.numero = numero;
    }

    /**
     * Imprime informações da revista.
     * @return
     */
    @Override
    public String toString()
    {
        return "Título: " + getTitulo() + "\n Autor: " + getAutor() + "\n Ano: " + getAno()
                + "\nQuantidade disponível: " + getQuantidadeDisponivel() + "\nVolume: " + volume
                + "\nNúmero: " + numero;
    }
}
