package src.Itens;

/**
 * Especifidade de item
 */
public class Livro extends  Item {
    private String editora;
    private String ISBN;

    public Livro(String titulo, String autor, int ano, int quantidadeDisponivel, int quantidadeEmprestada, String editora, String ISBN) {
        super(titulo, autor, ano, quantidadeDisponivel, quantidadeEmprestada);
        this.editora = editora;
        this.ISBN = ISBN;
    }


    /**
     * Imprime informações do livro.
     * @return
     */
    public String toString()
    {
    return "Título: " +  getTitulo() + "\nAutor: " + getAutor() + "\n Editora: " + editora
        + "\nAno: " +  getAno() +  "\n ISBN: " + ISBN;
    }



}
