package src.Itens;

import src.Exceptions.UnavaliableItemException;

import java.io.Serializable;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Classe abstrata item, que serve de base para itens específicos da biblioteca.
 */
public abstract class Item implements Serializable {
    private String titulo;
    private String autor;
    private int ano;
    private int quantidadeDisponivel;
    private int quantidadeEmprestada;

    public Item(String titulo, String autor, int ano, int quantidadeDisponivel, int quantidadeEmprestada) {
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
        this.quantidadeDisponivel = quantidadeDisponivel;
        this.quantidadeEmprestada = quantidadeEmprestada;
    }
    public Item()
    {
        this.titulo = null;
        this.autor = null;
        this.ano = 0;
        this.quantidadeDisponivel = 0;
        this.quantidadeEmprestada = 0;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }

    public void setQuantidadeDisponivel(int quantidadeDisponivel) {
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public int getQuantidadeEmprestada() {
        return quantidadeEmprestada;
    }

    public void setQuantidadeEmprestada(int quantidadeEmprestada) {
        this.quantidadeEmprestada = quantidadeEmprestada;
    }

    /**
     * Busca um item pelo nome dentro da lista de itens. Retorna o item caso encontra.
     * @param itens
     * @param nome
     * @return
     * @throws UnavaliableItemException
     */
    public static Item searchForItem(ArrayList<Item> itens, String nome) throws UnavaliableItemException {
        if(!nome.contains("."))
            nome = nome.concat(".");
        for (Item iten : itens) {
            if (iten.getTitulo().equalsIgnoreCase(nome) || iten.getTitulo().toLowerCase().contains(nome.subSequence(0, 10)))
            {
                if(iten.getQuantidadeDisponivel() == 0)
                    throw new UnavaliableItemException("Item indisponível");
                iten.setQuantidadeDisponivel(iten.getQuantidadeDisponivel() - 1);
                return iten;
            }
        }
       return null ;
    }




}
