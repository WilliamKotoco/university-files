package src.Enums;

/**
 * Oferece todas as opções de departamento existentes do ibilce.
 */
public enum Departamentos {
    DCCE(1,"Departamento de Ciência da Computação e estatística"),
    DMAT (2,"Departamento de Matemática"),
    DCB(3,"Departamento de Ciências Biológicas"),
    DE (4,"Departamento de Educação"),
    DETA(5,"Departamento de Engenharia e Tecnologia de Alimentos"),
    DELL(6,"Departamento de Estudos Linguísticos e Literários"),
    DF ( 7,"Departamento de Física"),
    DLM(8,"Departamento de Línguas Modernas"),
    DQCA(9,"Departamento de Química e Ciências Ambientais");

    private final String title;
    private final int id;
    Departamentos(int id,String title) {
        this.title = title;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public int getId() {
        return id;
    }
}
