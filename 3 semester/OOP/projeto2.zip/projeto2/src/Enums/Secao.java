package src.Enums;

/**
 * Seções em que o técnico pode trabalhar dentro do ibilce
 */
public enum Secao {
    ACADEMICA(1,"ACADEMICA"),
    POS_GRADUACAO(2,"Pós graduação"),
    GRADUACAO(3,"Graduação"),
    ADMINISTRATIVA(4,"Administrativa"),
    SAUDE(5,"Saúde");

    private final int id;
    private final String title;

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    Secao(int id, String title) {
        this.title = title;
        this.id = id;
    }
}
