    package src.Enums;

/**
 * Titulações possíveis do professor.
 */
public enum Titulacao {

    MESTRADO(1,"Mestre"),
    DOUTORADO(2,"Doutor"),
    POS_DOUTORADO(3,"Pós Doutor");
    private final String title;
    private final int id;

    Titulacao(int id, String title) {
        this.title = title;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public int getId() {
        return id;
    }
}
