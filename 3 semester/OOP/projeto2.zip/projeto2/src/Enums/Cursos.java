package src.Enums;

/**
 * Opções de cursos existentes na qual o aluno pode escolher
 */
public enum Cursos {
    CIENCIA_COMPUTACAO(1, "Ciência da Computação"),
    FISICA(2, "Física"),
    MATEMATICA(3, "Matemática"),
    PEDAGOGIA(4, "Pedagogia"),
    TRADUCAO(5, "Tradução"),
    LETRAS(6, "Letras"),
    QUIMICA(7, "Química"),
    ENGENHARIA_ALIMENTOS(8, "Engenharia de Alimentos");

    private final String titulo;
    private final int id;

    Cursos(int id, String titulo) {
        this.titulo = titulo;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }
}
