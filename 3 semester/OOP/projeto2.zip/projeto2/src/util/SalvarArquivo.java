package src.util;

import src.Itens.Item;
import src.system.Emprestimo;
import src.users.Usuario;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * Classe que provém a utilidade de salvar os dados nos arquivos, para que não sejam
 * perdidos os dados.
 */
public final class SalvarArquivo {


    /**
     * Salva os empréstimos em um arquivo serializável.
     * @param emprestimos
     */
    public static void salvarEmprestimo(ArrayList<Emprestimo> emprestimos)
    {
        try {
            FileOutputStream output = new FileOutputStream(Paths.get("file/emprestimos.ser").toFile());
            ObjectOutputStream objectOutput = new ObjectOutputStream(output);
            objectOutput.writeObject(emprestimos);
            objectOutput.close();
            output.close();

        } catch (FileNotFoundException e) {
            System.out.println("Arquivo emprestimo.ser não existe");

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /**
     * Salva somente um único item no arquivo txt, visto que os itens seguem tudo
     * um padrão dado pelo Professor.
     * @param linha
     */
    public static void salvarItemIndividual(String linha)
    {
        try

        {
            FileWriter fileWriter = new FileWriter("file/items.txt", true);
            PrintWriter pw = new PrintWriter(fileWriter);
            pw.write(linha.concat("\n"));
            fileWriter.close();
            pw.close();


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Salva um usuário no arquivo serializável.
     * @param users
     */
    public static void salvarUsuario(ArrayList<Usuario> users)
    {
        try {
            FileOutputStream output = new FileOutputStream(Paths.get("file/users.ser").toFile());
            ObjectOutputStream objectOutput = new ObjectOutputStream(output);
            objectOutput.writeObject(users);
            objectOutput.close();
            output.close();

        } catch (FileNotFoundException e) {
            System.out.println("Arquivo users.ser não existe");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



}
