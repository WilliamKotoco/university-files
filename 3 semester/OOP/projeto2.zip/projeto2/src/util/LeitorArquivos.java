package src.util;

import src.Itens.CD;
import src.Itens.Item;
import src.Itens.Livro;
import src.Itens.Revista;
import src.system.Emprestimo;
import src.users.Usuario;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe cujo único objetivo é ler os arquivos e retornar as informações
 */
public final class LeitorArquivos {


    /**
     * Lê os arquivos dos itens
     * @return ArrayList com os itens
     */
    public static ArrayList<Item> readItensFile() {
        File itensFile = new File("file/items.txt");

        Scanner file = null;
        ArrayList<Item> itens = new ArrayList<>();

        try {
            file = new Scanner(itensFile);
            while (file.hasNextLine()) {
                String line = file.nextLine();
                String[] campos = line.split("#");
                String nome = campos[1];
                String autor = campos[2];
                Item item;
                int ano = Integer.parseInt(campos[3]);
                int quantidadeDisponivel = Integer.parseInt(campos[4]);
                final int quantidadeEmprestada = 0;
                if (campos[0].equals("Livro")) {
                    String editora = campos[5];
                    String ISBN = campos[6];
                    item = new Livro(nome, autor, ano, quantidadeDisponivel, quantidadeEmprestada, editora, ISBN);
                } else if (campos[0].equals("Revista")) {
                    String volume = campos[5];
                    int numero = Integer.parseInt(campos[6]);
                    item = new Revista(nome, autor, ano, quantidadeDisponivel, quantidadeEmprestada, volume, numero);
                } else {
                    String volume = campos[5];
                    String gravadora = campos[6];
                    item = new CD(nome, autor, ano, quantidadeDisponivel, quantidadeEmprestada, volume, gravadora);
                }
                itens.add(item);

            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } finally {
            if (file != null)
                file.close();

        }
        return itens;
    }

    /**
     * Lê o arquivo dos usuários
     * @return ArrayList com todos usuários
     */
    public static ArrayList<Usuario> readUsersFile()
    {
        ArrayList<Usuario> users = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(Paths.get("file/users.ser").toFile());

            ObjectInputStream input = new ObjectInputStream(fileInputStream);
            Object user_Array = input.readObject();
            users = (ArrayList<Usuario>) user_Array;
            input.close();
            fileInputStream.close();
        } catch (FileNotFoundException ex) {
            //throw new RuntimeException(ex);
        } catch (IOException ex) {
            //  throw new RuntimeException(ex);
        } catch (ClassNotFoundException ex) {

        }

        return users;
    }

    /**
     * Lê o arquivo dos empréstimos
     * @return ArrayList dos empréstimos
     */
    public static ArrayList<Emprestimo> lerEmprestimos()
    {
        ArrayList<Emprestimo> emprestimos= new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(Paths.get("file/emprestimos.ser").toFile());

            ObjectInputStream input = new ObjectInputStream(fileInputStream);
            Object emprestimo_Array = input.readObject();
            emprestimos = (ArrayList<Emprestimo>) emprestimo_Array;
            input.close();
            fileInputStream.close();
        } catch (FileNotFoundException ex) {
            //throw new RuntimeException(ex);
        } catch (IOException ex) {
            //  throw new RuntimeException(ex);
        } catch (ClassNotFoundException ex) {

        }

        return emprestimos;

    }

}

