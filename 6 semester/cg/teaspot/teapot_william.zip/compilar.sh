g++ teapot.cpp -o teapot -lGL -lGLU -lglut -lGLEW -lglfw -lSOIL

