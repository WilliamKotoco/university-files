gcc -o projeto -lGL -lGLU -lglut -lm *.c *.h
