#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/glu.h>
#include <GL/glut.h>

/// \brief Essa função desenha uma esfera usando o glut
void desenha_cone();
