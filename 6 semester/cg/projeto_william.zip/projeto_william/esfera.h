#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/glu.h>
#include <GL/glut.h>

/// @brief Desenha uma esfera na tela
void desenha_esfera();
