#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/glu.h>
#include <GL/glut.h>

/// @brief Essa função desenha um cubo na tela
/// Ela é chamd
void desenha_cubo();
